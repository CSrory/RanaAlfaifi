# التعرف الحي: الكاميرا -> MediaPipe يحدد اليد -> قص -> رمادي 64x64 -> CNN -> حرف -> كلمة
import cv2, json, time, numpy as np, mediapipe as mp
from tensorflow import keras
from letters import AR

model = keras.models.load_model("model.keras")
names = json.load(open("labels.json"))
hands = mp.solutions.hands.Hands(max_num_hands=1, min_detection_confidence=0.6)
cap = cv2.VideoCapture(0)
text, last, count, STABLE, CONF = "", None, 0, 12, 0.75   # عدّل الحساسية

while True:
    ok, frame = cap.read()
    if not ok: break
    frame = cv2.flip(frame, 1)
    h, w = frame.shape[:2]
    res = hands.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    label, conf = None, 0
    if res.multi_hand_landmarks:
        pts = np.array([[p.x*w, p.y*h] for p in res.multi_hand_landmarks[0].landmark])
        cx, cy = pts.mean(0); r = int(max(np.ptp(pts[:, 0]), np.ptp(pts[:, 1])) * 0.75)
        x0, y0 = max(int(cx)-r, 0), max(int(cy)-r, 0)
        crop = frame[y0:int(cy)+r, x0:int(cx)+r]
        if crop.size:
            g = cv2.resize(cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY), (64, 64))
            p = model.predict(g[None, ..., None], verbose=0)[0]
            label, conf = names[int(p.argmax())], float(p.max())
            cv2.rectangle(frame, (x0, y0), (int(cx)+r, int(cy)+r), (0, 255, 0), 2)
    # تثبيت الحرف: لازم يتكرر عدة فريمات قبل ما يُقبل
    if label and conf > CONF and label == last: count += 1
    else: count = 0
    last = label if label and conf > CONF else None
    if count == STABLE:
        text += AR.get(label, "?"); count = -STABLE * 2        # فاصل قبل قبول حرف جديد
    cv2.putText(frame, f"{label} {conf:.2f}", (10, 30), 0, 1, (0, 255, 0), 2)
    cv2.putText(frame, "SPACE=space  BACKSPACE=del  C=clear  Q=quit", (10, h-10), 0, 0.5, (255, 255, 255), 1)
    cv2.imshow("WASL phase 1", frame)
    k = cv2.waitKey(1) & 0xFF
    if k == ord("q"): break
    elif k == 32: text += " "
    elif k == 8: text = text[:-1]
    elif k == ord("c"): text = ""
    print("\r" + text, end="")        # المرحلة 2: النص العربي يتجمع هنا (تجاوز: اعرضه في واجهتك لاحقاً)
cap.release(); cv2.destroyAllWindows()
