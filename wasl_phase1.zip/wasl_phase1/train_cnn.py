# الاستخدام: python train_cnn.py مسار_الداتاسيت
# الشرط: مجلد لكل حرف:  dataset/ain/*.jpg  dataset/bb/*.jpg ...
import sys, json, tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

D, S = sys.argv[1], 64
kw = dict(image_size=(S, S), color_mode="grayscale", batch_size=64, validation_split=0.15, seed=1)
tr = keras.utils.image_dataset_from_directory(D, subset="training", **kw)
va = keras.utils.image_dataset_from_directory(D, subset="validation", **kw)
names = tr.class_names
json.dump(names, open("labels.json", "w"))
print(len(names), "حرف:", names)

m = keras.Sequential([
    layers.Input((S, S, 1)), layers.Rescaling(1/255),
    layers.RandomRotation(0.08), layers.RandomZoom(0.1), layers.RandomContrast(0.2),   # يقرّب الداتا من الكاميرا الحقيقية
    layers.Conv2D(32, 3, activation="relu"), layers.MaxPooling2D(),
    layers.Conv2D(64, 3, activation="relu"), layers.MaxPooling2D(),
    layers.Conv2D(128, 3, activation="relu"), layers.MaxPooling2D(),
    layers.Flatten(), layers.Dropout(0.4), layers.Dense(128, activation="relu"),
    layers.Dense(len(names), activation="softmax")])
m.compile("adam", "sparse_categorical_crossentropy", metrics=["accuracy"])
m.fit(tr.prefetch(2), validation_data=va.prefetch(2), epochs=12)
m.save("model.keras")
